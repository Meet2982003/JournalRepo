package com.mtspace.journalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharePointApplicationTests {

	@Test
	void contextLoads() {
	}

}
