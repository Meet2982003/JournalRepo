package com.mtspace.journalApp.service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.mtspace.journalApp.entity.SharePointEntry;
import com.mtspace.journalApp.entity.User;
import com.mtspace.journalApp.repository.SharePointEntryRepo;
import com.mtspace.journalApp.repository.UserRepo;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UserService {
	@Autowired
	private UserRepo userRepositry;
	
	private static final PasswordEncoder passwordEncoder=new BCryptPasswordEncoder();
	
	public boolean saveNewUser(User user) {// localhost:8085 (post)
	try{		
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user.setRoles(Arrays.asList("USER"));
		userRepositry.save(user);
		return true;
	}
	catch (Exception e) {
		return false;
	}
	}
	public void saveAdmin(User user) // localhost:8085 (post)
	{		
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		user.setRoles(Arrays.asList("USER","ADMIN"));
		userRepositry.save(user);
	
	}
	public void saveUser(User user) // localhost:8085 (post)
	{		
			userRepositry.save(user);
	

	}
//	
//	public void saveEntry(SharePointEntry sharePointEntries) {
//		sharePointEntryRepositry.save(sharePointEntries);
//	}
	public List<User> getAll(){
		return userRepositry.findAll();
	}
	
	public Optional<User> findById(ObjectId id) {
		return userRepositry.findById(id);
	}
	public void deleteById(ObjectId id) {
		userRepositry.deleteById(id);
	}
	public User findByUserName(String userName) {
		return userRepositry.findByUserName(userName);
	}
}


//  controller --> service --> repository