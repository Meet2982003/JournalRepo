package com.mtspace.journalApp.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.mtspace.journalApp.entity.SharePointEntry;
import com.mtspace.journalApp.entity.User;
import com.mtspace.journalApp.repository.SharePointEntryRepo;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SharePointEntryService {
	@Autowired
	private SharePointEntryRepo sharePointEntryRepositry;
	
	@Autowired
	private UserService userService;
	
	@Transactional
	public void saveEntry(SharePointEntry myEntry, String userName) // localhost:8085 (post)
	{
		try {
			User user=userService.findByUserName(userName);
			myEntry.setDate(LocalDateTime.now());
			SharePointEntry saved=sharePointEntryRepositry.save(myEntry);
			user.getSharePointEntries().add(saved);
			userService.saveUser(user);
			
		} catch (Exception e) {
			 log.error("Exception",e);
		}
	

	}
	public void saveEntry(SharePointEntry myEntry) // localhost:8085 (post)
	{
		try {
			
			sharePointEntryRepositry.save(myEntry);
			
		} catch (Exception e) {
			 log.error("Exception",e);
		}
	

	}
//	
//	public void saveEntry(SharePointEntry sharePointEntries) {
//		sharePointEntryRepositry.save(sharePointEntries);
//	}
	public List<SharePointEntry> getAll(){
		return sharePointEntryRepositry.findAll();
	}
	
	public Optional<SharePointEntry> findById(ObjectId id) {
		return sharePointEntryRepositry.findById(id);
	}
	
	@Transactional
	public boolean deleteById(ObjectId id,String userName) {
		boolean removed= false;
		try {
		User user=userService.findByUserName(userName);
		removed=user.getSharePointEntries().removeIf(z -> z.getId().equals(id));
		if(removed) {
			userService.saveUser(user);
			sharePointEntryRepositry.deleteById(id);
		}
		

		}catch(Exception e) {
			throw new RuntimeException("A error occured while deleting the entry",e);
		}return removed;
	}
//	public List<SharePointEntry> findByUserName(String userName){
//		return sharePointEntryRepositry.f;
//		
//	}
}


//  controller --> service --> repository