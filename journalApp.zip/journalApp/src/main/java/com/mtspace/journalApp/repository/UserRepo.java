package com.mtspace.journalApp.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mtspace.journalApp.entity.SharePointEntry;
import com.mtspace.journalApp.entity.User;


public interface UserRepo extends MongoRepository<User,ObjectId>{
	User findByUserName(String username);
	
	void deleteByUserName(String username);
}